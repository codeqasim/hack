<?php

$to ="hajime.sakata00@yandex.com, ryu.siyoon1@gmail.com";

?>